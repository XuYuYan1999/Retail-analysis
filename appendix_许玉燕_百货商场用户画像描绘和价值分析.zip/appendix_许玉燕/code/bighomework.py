# 2015-2018年不同月份消费金额
# import os
# os.chdir(r'D:\data')
# import pandas as pd
# import numpy as np
# from datetime import datetime
# df=pd.read_csv('./xiangmu/hebingdata.csv')
# df['dtime']=pd.to_datetime(df['dtime'])
# df['month']=df.dtime.values.astype('datetime64[M]')
# import matplotlib.pyplot as plt
# plt.figure(figsize = (10,4))
# ax=df.groupby('month').je.sum().plot(c='r')
# ax.set_xlabel('Month(2015-2018)')
# ax.set_ylabel('Money')
# ax.set_title('Consumption In Different Months')
# plt.savefig('./xiangmu/Consumption In Different Months.jpg')
# plt.show()
# --------------------------------------------------------------
# 不同年份消费金额
# import os
# os.chdir(r'D:\data')
# import pandas as pd
# import numpy as np
# from datetime import datetime
# df=pd.read_csv('./xiangmu/hebingdata.csv')
# df['dtime']=pd.to_datetime(df['dtime'])
# df['year']=df['dtime'].dt.year
# # df['year']=df.dtime.values.astype('datetime64[M]')
# import matplotlib.pyplot as plt
# plt.figure(figsize = (10,4))
# ax=df.groupby(df['year']).je.sum().plot(c='r')
# ax.set_xlabel('Year(2015-2018)')
# ax.set_ylabel('Money')
# ax.set_title('Consumption In Different Years')
# plt.savefig('./xiangmu/Consumption In Different Years.jpg')
# plt.show()
# ------------------------------------------------------------------
# 不同年龄层会员人数
# import os
# os.chdir(r'D:\data')
# import pandas as pd
# df=pd.read_excel('./xiangmu/cumcm.xlsx')
# df['csrq'] = pd.to_datetime(df['csrq'])
# df.dropna()
# df['year']= df['csrq'].dt.year
# bins=[1922,1960,1990,2005]
# score_cut = pd.cut(df['year'], bins)
# print(type(score_cut))
# print(score_cut)
# a=pd.value_counts(score_cut)
# import matplotlib.pyplot as plt
# plt.figure(figsize=(4, 4))
# labels=['old','midth','young']
# colors=['powderblue','darkturquoise','cadetblue']
# explode = (0.05, 0, 0)
# plt.pie(a,explode=explode,labels=labels,colors=colors,autopct='%.2f %%')
# plt.legend(loc='upper right')
# plt.title('Age distribution of membership')
# plt.savefig('./xiangmu/Age distribution of membership.jpg')
# plt.show()
# --------------------------------------------------------------------------
# 不同年龄层会员消费金额
# import os
# os.chdir(r'D:\data')
# import pandas as pd
# df=pd.read_csv('./xiangmu/hebingdata.csv')
# df.dropna(subset=['je'])
# df['csrq'] = pd.to_datetime(df['csrq'])
# df['year']= df['csrq'].dt.year
# b=df['je']
# bins=[1922,1960,1990,2005]
# labels=('young','midth','old')
# score_cut = pd.cut(df['year'], bins)
# # print(score_cut )
# sum1=0
# sum2=0
# sum3=0
# for i in range(len(df['year'])):
#     if score_cut[i]=='young':
#         sum1+=b[i]
#     elif score_cut[i]=='midth':
#         sum2+=b[i]
#     else:
#         sum3+=b[i]
# num=[sum1,sum2,sum3]
# import matplotlib.pyplot as plt
# plt.figure(figsize=(4, 4))
# # ==plt.pie(num,labels=labels,autopct='%.4f %%')
# ax=plt.bar(range(len(num)),num,color='cadetblue',edgecolor = 'black')
# plt.title('Consumption In Different Age Groups')
# plt.xticks(range(len(num)),['young','midth','old'])
# plt.xlabel('Different Age Groups')
# plt.ylabel('Money')
# plt.savefig('./xiangmu/Consumption In Different Age Groups.jpg')
# plt.show()
# ----------------------------------------------------------------------
# 会员和非会员人数
# import os
# os.chdir(r'D:\data')
# import pandas as pd
# df=pd.read_csv('./xiangmu/hebingdata.csv')
# b=df['je']
# woman=0
# man=0
# for i in range(len(df['xb'])):
#     if df['xb'][i]==0:
#         woman+=i
#     else:
#         man+=i
# num=[woman,man]
# for i in range(len(df['xb'])):
#     if df['xb'][i]==0:
#         woman+=b[i]
#     else:
#         man+=b[i]
# num=[woman,man]
# import matplotlib.pyplot as plt
# plt.figure(figsize=(4, 4))
# labels=['woman','man']
# colors=['lightcoral','darkred']
# explode = (0.1, 0)
# plt.pie(num,explode=explode,labels=labels,colors=colors,autopct='%.2f %%')
# plt.legend(loc='upper right')
# plt.title('Gender-specific consumption')
# plt.savefig('./xiangmu/Gender-specific consumption.jpg')
# plt.show()
# ---------------------------------------------------------------------------
# 会员和非会员消费金额
# import os
# os.chdir(r'D:\data')
# import pandas as pd
# df=pd.read_csv('./xiangmu/cumcm2018c2.csv')
# kh=df['kh']
# # member=0
# # outsider=0
# for i in range(len(kh)):
#     if kh[i]!=[]:
#         i+=i
# for j in range(len(kh)):
#     if kh[j]==[]:
#         j+=j
# num=[i,j]
# import matplotlib.pyplot as plt
# plt.figure(figsize=(4, 4))
# labels=['member','outsider']
# colors=['darksalmon','seashell']
# explode = (0.1, 0)
# plt.pie(num,explode=explode,labels=labels,colors=colors,autopct='%.2f %%')
# plt.legend(loc='upper right')
# plt.title('Details Of Customer Distribution')
# plt.savefig('./xiangmu/Details Of Customer Distribution.jpg')
# plt.show()
# ---------------------------------------------------------------------------
# import os
# os.chdir(r'D:\data')
# import pandas as pd
# df=pd.read_csv('./xiangmu/cumcm2018c2.csv')
# kh=df['kh']
# je=df['je']
# member=0
# outsider=0
# for i in range(len(kh)):
#     if kh[i]!=0:
#         member+=je[i]
# for j in range(len(kh)):
#     if kh[j]==0:
#         outsider+=je[i]
# num=[member,outsider]
# print(num)
# -------------------------------------------------------------------
# 不同时间段人数
# import os
# os.chdir(r'D:\data')
# import pandas as pd
# df=pd.read_csv('./xiangmu/hebingdata.csv')
# data=df['dtime']=pd.to_datetime(df['dtime'])
# df['hour']=df['dtime'].dt.hour
# b = [0,5,11,13,18,24]
# time_cut=pd.cut(df['hour'], bins=b)
# a=pd.value_counts(time_cut)
# import matplotlib.pyplot as plt
# plt.figure(figsize=(4, 4))
# labels=[ 'Early Morning','Morning','mid noon','Noon','Eve']
# colors=['plum','violet','indigo','darkorchid','purple']
# explode = (0,0,0.1,0,0)
# plt.pie(a,explode=explode,labels=labels,colors=colors,autopct='%.2f %%')
# plt.legend(loc='upper right')
# plt.title('Time-Segment distribution map')
# plt.savefig('./xiangmu/Time-Segment distribution map.jpg')
# plt.show()
# ---------------------------------------------------------------------------
# 不同季节的人数
# import os
# os.chdir(r'D:\data')
# import pandas as pd
# df=pd.read_csv('./xiangmu/hebingdata.csv')
# data=df['dtime']=pd.to_datetime(df['dtime'])
# df['month']=df['dtime'].dt.month
# spring=0
# summer=0
# fall=0
# winter=0
# b=df['je']
# for i in range(len(data)):
#     if df['month'][i]>=3&df['month'][i]<=5:
#         spring+=b[i]
#     if df['month'][i]>=6&df['month'][i]<=8:
#         summer+=b[i]
#     if df['month'][i]>=9&df['month'][i]<=11:
#         fall+=b[i]
#     if df['month'][i]>=12&df['month'][i]<=2:
#         winter+=b[i]
# num=[spring,summer,fall,winter]
# import matplotlib.pyplot as plt
# plt.figure(figsize=(4, 4))
# labels=[ 'spring','summer','fall','winter']
# colors=['orangered','coral','tomato','sienna']
# explode = (0,0,0.1,0)
# plt.pie(num,explode=explode,labels=labels,colors=colors,autopct='%.2f %%')
# plt.legend(loc='upper right')
# plt.title('Consumption In Different Seasons')
# plt.savefig('./xiangmu/Consumption In Different Seasons.jpg')
# plt.show()
# ---------------------------------------------------------------------------------
# import os
# os.chdir(r'D:\data')
# import pandas as pd
# import numpy as np
# df=pd.read_csv('./xiangmu/hebingdata1.csv')
# df1_sum=df.groupby('dtime')['sl','je'].sum()
# df1_sum.to_csv('./xiangmu/cumcm2018c3.csv')
# df2=pd.read_csv('./xiangmu/cumcm2018c3.csv')
#
# data2=df2['dtime']= pd.to_datetime(df2['dtime'])
# a=df['year']=df2['dtime'].dt.year
#
# datafile=df[['dtime','sl','je']]
# timelengeh=2020-a
# datafile1=datafile.copy()
# datafile1['R']=timelengeh
# datafile1['F']=datafile['sl']
# datafile1['M']=datafile['je']
# datafile2=datafile1[['R','F','M']]
# def Z_score(data):
#     data=np.array(data).astype(np.float)
#     data=(data-data.mean())/data.std()
#     # data.columns=['Z'+ i for i in data.columns]
#     return data
# datafile3=Z_score(datafile2)
#
# from sklearn.cluster import KMeans
# model=KMeans(n_clusters=3,n_jobs=4)
# model.fit(datafile3)
# r1=pd.Series(model.labels_).value_counts()
# r2=pd.DataFrame(model.cluster_centers_)
# r=pd.concat([r2,r1],axis=1)
# # r.columns=list(datafile3.columns)+['类别数目']
# import matplotlib.pyplot as plt
# plt.style.use('ggplot')
# plt.rcParams['font.sans-serif']='simkai'
# plt.rcParams['axes.unicode_minus']=False
# labels=np.array(['R','F','M'])
# datalLength=3
# N=len(r2)
# angels=np.linspace(0,2*np.pi,N,endpoint=False)
# data_3=pd.concat([r2,r2.loc[:,0]],axis=1)
# # data_3=np.concatenate((labels,[labels[0]]))
# angels=np.concatenate((angels,[angels[0]]))
# fig=plt.figure(figsize=(6,6))
# ax=fig.add_subplot(111,polar=True)
# for i in range(0,3):
#     j=i+1
#     ax.plot(angels,data_3.loc[i,:],'o-',linewidth=2,label='Customers{0}'.format(j))
# ax.set_thetagrids(angels*180/np.pi,labels)
# ax.set_title('客户群特征分析',va='bottom',fontproperties='SimHei')
# ax.set_rlim(-1,2.5)
# ax.grid(True)
# plt.legend()
# plt.savefig('./xiangmu/differ class.pdf')
# plt.show()













